<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>HALAMAN CREATE WEBP</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
:root{
    --primary:#8b5cf6;
    --secondary:#06b6d4;
    --accent:#3b82f6;
    --text:#ffffff;
    --card-bg:rgba(255,255,255,.06);
}

*{
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

html,body{
    margin:0;
    padding:0;
    min-height:100%;
    color:var(--text);
    background:linear-gradient(
        135deg,
        #050816,
        #0f172a,
        #111827,
        #1e1b4b
    );
    background-size:400% 400%;
    animation:bgMove 12s ease infinite;
}

@keyframes bgMove{
    0%{background-position:0% 50%;}
    50%{background-position:100% 50%;}
    100%{background-position:0% 50%;}
}

canvas.particles-bg{
    position:fixed;
    top:0;
    left:0;
    width:100%;
    height:100%;
    z-index:-1;
}

.container{
    max-width:1100px;
    margin:auto;
    padding:50px 15px 30px;
}

h1{
    text-align:center;
    font-size:2.8rem;
    font-weight:700;
    margin-bottom:40px;
    background:linear-gradient(
        90deg,
        #ffffff,
        #60a5fa,
        #8b5cf6,
        #06b6d4
    );
    background-size:300% auto;
    -webkit-background-clip:text;
    color:transparent;
    animation:shine 6s linear infinite;
    letter-spacing:2px;
}

@keyframes shine{
    to{
        background-position:300% center;
    }
}

.grid-container{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:25px;
}

.card-form{
    background:rgba(255,255,255,.05);
    border:1px solid rgba(255,255,255,.08);
    backdrop-filter:blur(15px);
    border-radius:18px;
    padding:12px;
    transition:.35s;
    overflow:hidden;
}

.card-form:hover{
    transform:translateY(-8px);
    box-shadow:
    0 0 25px rgba(139,92,246,.35),
    0 0 40px rgba(6,182,212,.25);
}

.card-form img{
    width:100%;
    height:180px;
    object-fit:cover;
    border-radius:12px;
    transition:.35s;
}

.card-form:hover img{
    transform:scale(1.05);
}

.card-title{
    margin-top:12px;
    margin-bottom:12px;
    font-size:14px;
    font-weight:600;
    text-align:center;
    color:#e5e7eb;
}

.card-form button{
    width:100%;
    border:none;
    padding:12px;
    border-radius:12px;
    font-weight:700;
    cursor:pointer;
    color:white;
    background:linear-gradient(
        135deg,
        #8b5cf6,
        #3b82f6,
        #06b6d4
    );
    transition:.3s;
}

.card-form button:hover{
    transform:scale(1.03);
    box-shadow:
    0 0 20px rgba(139,92,246,.6),
    0 0 35px rgba(6,182,212,.4);
}

.copyright{
    text-align:center;
    margin-top:50px;
    color:#9ca3af;
    font-size:13px;
}

.copyright a{
    color:#60a5fa;
    text-decoration:none;
}

.copyright a:hover{
    color:#8b5cf6;
}

@media(max-width:768px){

    .container{
        padding:25px 12px;
    }

    h1{
        font-size:2rem;
    }

    .grid-container{
        gap:15px;
    }

    .card-form img{
        height:320px;
    }
}
  </style>
</head>
<body>

<canvas class="particles-bg" id="particles"></canvas>

<div class="container">
  <h1>HALAMAN CREATE</h1>

  <div class="grid-container">
    <form class="card-form" action="memek.php" method="post">
      <img src="https://files.catbox.moe/5ah6k7.jpg" alt="Skin 1">
      <div class="card-title">VIDEY</div>
      <input type="hidden" name="nomor" value="10">
      <button type="submit" name="buatweb">BUAT WEB</button>
    </form>

    <form class="card-form" action="memek.php" method="post">
      <img src="https://files.catbox.moe/7wbatj.jpg" alt="Skin 2">
      <div class="card-title">GRUB WHATSAPP</div>
      <input type="hidden" name="nomor" value="6">
      <button type="submit" name="buatweb">BUAT WEB</button>
    </form>

    <form class="card-form" action="memek.php" method="post">
      <img src="https://files.catbox.moe/ioz4mz.jpg" alt="Skin 3">
      <div class="card-title">MISSAV</div>
      <input type="hidden" name="nomor" value="7">
      <button type="submit" name="buatweb">BUAT WEB</button>
    </form>
    
    <form class="card-form" action="memek.php" method="post">
      <img src="https://files.catbox.moe/tb66d6.jpg" alt="Skin 3">
      <div class="card-title">DOWNLOAD AVCODE</div>
      <input type="hidden" name="nomor" value="8">
      <button type="submit" name="buatweb">BUAT WEB</button>
    </form>
    

<script>
  const canvas = document.getElementById('particles');
  const ctx = canvas.getContext('2d');
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;

  let particles = [];
  for (let i = 0; i < 80; i++) {
    particles.push({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      radius: Math.random() * 2 + 1,
      dx: (Math.random() - 0.5) * 0.4,
      dy: (Math.random() - 0.5) * 0.4
    });
  }

  function drawParticles() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = 'rgba(0, 255, 255, 0.5)';
    particles.forEach(p => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fill();
      p.x += p.dx;
      p.y += p.dy;
      if (p.x < 0 || p.x > canvas.width) p.dx *= -1;
      if (p.y < 0 || p.y > canvas.height) p.dy *= -1;
    });
    requestAnimationFrame(drawParticles);
  }

  drawParticles();

  window.addEventListener('resize', () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  });
</script>

</body>
</html>