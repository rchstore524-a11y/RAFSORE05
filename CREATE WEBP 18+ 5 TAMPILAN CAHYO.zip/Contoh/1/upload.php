<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil data dari form
    $namaresult = $_POST["nama-res"];
    $emailresult = $_POST["email-res"];

    // Tentukan path file yang akan diubah dan kontennya
    $filePath = 'data.php';
    $newContent = "<?php
\$sender = '$namaresult';
\$email = '$emailresult';
?>";

    // Menulis data baru ke file
    if (file_put_contents($filePath, $newContent) !== false) {
        echo "Success Mengubah Data Anda.";
    } else {
        echo "Gagal mengubah file. Pastikan izin tulis sudah diberikan.";
    }
} else {
    echo "Metode permintaan tidak valid.";
}
?>
