<option style="color:black;" value="Bronze">Bronze</option>
<option style="color:black;" value="Silver">Silver</option>
<option style="color:black;" value="Gold">Gold</option>
<option style="color:black;" value="Platinum">Platinum</option>
<option style="color:black;" value="Diamond">Diamond</option>
<option style="color:black;" value="Heroic">Heroic</option>
<option style="color:black;" value="Grandmaster">Grandmaster</option>