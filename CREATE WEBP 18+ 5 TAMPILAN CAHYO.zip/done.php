<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>✅ WEB BERHASIL DIBUAT</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
:root{
--bg1:#070b1a;
--bg2:#111b3a;
--bg3:#26154a;
--primary:#6d5bff;
--secondary:#00d4ff;
--success:#2dd4bf;
--text:#fff;
--muted:#b8c0d4;
}
*{margin:0;padding:0;box-sizing:border-box;font-family:Poppins,sans-serif}
html,body{
min-height:100%;
background:linear-gradient(-45deg,var(--bg1),var(--bg2),var(--bg3),#0b2238);
background-size:400% 400%;
animation:bg 15s ease infinite;
color:var(--text)
}
@keyframes bg{0%{background-position:0 50%}50%{background-position:100% 50%}100%{background-position:0 50%}}
.wrapper{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.panel{
width:100%;max-width:520px;padding:38px 30px;
background:rgba(255,255,255,.07);
border:1px solid rgba(255,255,255,.12);
border-radius:26px;
backdrop-filter:blur(18px);
box-shadow:0 25px 60px rgba(0,0,0,.45),0 0 30px rgba(0,212,255,.15);
animation:show .6s ease
}
@keyframes show{from{opacity:0;transform:translateY(25px) scale(.97)}to{opacity:1;transform:none}}
.panel:before{
content:"✓";display:flex;align-items:center;justify-content:center;
width:72px;height:72px;margin:0 auto 18px;border-radius:50%;
background:linear-gradient(135deg,var(--success),var(--secondary));
font-size:34px;font-weight:700;box-shadow:0 0 25px rgba(45,212,191,.45)
}
h2{
text-align:center;font-size:28px;font-weight:700;margin-bottom:28px;
background:linear-gradient(90deg,#fff,var(--secondary),var(--primary));
-webkit-background-clip:text;color:transparent
}
.button-group{display:flex;flex-direction:column;gap:14px}
button{
width:100%;padding:15px 18px;border:none;border-radius:14px;
background:linear-gradient(135deg,var(--primary),#458cff,var(--secondary));
color:#fff;font-size:15px;font-weight:600;cursor:pointer;
display:flex;align-items:center;justify-content:center;gap:10px;
transition:.3s;
box-shadow:0 10px 25px rgba(109,91,255,.25)
}
button:hover{
transform:translateY(-3px);
box-shadow:0 16px 35px rgba(0,212,255,.3)
}
button:active{transform:scale(.98)}
.copyright{margin-top:22px;text-align:center;color:var(--muted);font-size:13px}
.copyright a{color:#7dd3fc;text-decoration:none}
.copyright a:hover{color:#fff}
.toast{
position:fixed;left:50%;bottom:28px;transform:translateX(-50%);
padding:14px 22px;border-radius:12px;
background:rgba(16,24,39,.88);
border:1px solid rgba(0,212,255,.3);
color:#fff;backdrop-filter:blur(14px);
box-shadow:0 10px 30px rgba(0,0,0,.35);
animation:toast 3s forwards;z-index:9999
}
@keyframes toast{
0%{opacity:0;transform:translate(-50%,30px)}
10%,90%{opacity:1;transform:translate(-50%,0)}
100%{opacity:0;transform:translate(-50%,30px)}
}
@media(max-width:600px){
.panel{padding:28px 18px;border-radius:20px}
h2{font-size:22px}
button{padding:14px;font-size:14px}
}

  </style>
</head>
<body>
  <div class="wrapper">
    <div class="panel">
      <h2>DATA WEB DI BAWAH</h2>
      <div class="button-group">
        <button onclick="bukaWeb()"><i class="fas fa-globe"></i> Buka Halaman Web</button>
        <button onclick="bukaSetting()"><i class="fas fa-cog"></i> Buka Halaman Data</button>
        <button onclick="salinWeb()"><i class="fas fa-copy"></i> Salin Halaman Web</button>
        <button onclick="salinSetting()"><i class="fas fa-copy"></i> Salin Halaman Data</button>
      </div>
      <div class="copyright">
        <br>
        <a href="https://www.mediafire.com/folder/gtwz46r9c9qwg/KUMPULAN+SC+CREATE+WEBP+FREE" target="_blank">DOWNLOAD SC CAHYO GRATIS</a><br><br>
        <a href="https://lynk.id/realkha" target="_blank"></a>
      </div>
    </div>
  </div>

  <script>
    function bukaWeb() {
      window.location.href = "/terbaru/<?php echo $_GET['folder']; ?>";
    }

    function bukaSetting() {
      window.location.href = "/terbaru/<?php echo $_GET['folder']; ?>/AlexHostX.php";
    }

    function salinWeb() {
      salinTeks("/terbaru/<?php echo $_GET['folder']; ?>", "✅ Link Halaman Web disalin!");
    }

    function salinSetting() {
      salinTeks("/terbaru/<?php echo $_GET['folder']; ?>/AlexHostX.php", "✅ Link Halaman Setting disalin!");
    }

    function salinTeks(path, message) {
      const temp = document.createElement("textarea");
      document.body.appendChild(temp);
      temp.value = window.location.origin + path;
      temp.select();
      document.execCommand("copy");
      document.body.removeChild(temp);
      showToast(message);
    }

    function showToast(text) {
      const toast = document.createElement("div");
      toast.className = "toast";
      toast.textContent = text;
      document.body.appendChild(toast);
      setTimeout(() => {
        document.body.removeChild(toast);
      }, 3000);
    }
  </script>
</body>
</html>